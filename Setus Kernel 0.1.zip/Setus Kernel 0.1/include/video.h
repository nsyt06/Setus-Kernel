#ifndef VIDEO_H
#define VIDEO_H

void clear_screen(void);
void print_string(const char *str);
void print_char(char c);

#endif
