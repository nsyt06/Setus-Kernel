#ifndef SHELL_H
#define SHELL_H

void start_shell(void);
void execute_command(char *command);

#endif
