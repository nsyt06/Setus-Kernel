#ifndef TIMER_H
#define TIMER_H

void init_timer(unsigned int frequency);
void timer_interrupt_handler(void);

#endif
