#ifndef TASK_H
#define TASK_H

typedef struct {
    unsigned int *stack_pointer;
    unsigned int id;
} task_t;

void init_tasking(void);
void scheduler(void);

#endif
