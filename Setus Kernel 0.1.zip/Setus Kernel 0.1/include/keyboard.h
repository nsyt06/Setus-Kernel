#ifndef KEYBOARD_H
#define KEYBOARD_H

char read_key(void);

#endif
