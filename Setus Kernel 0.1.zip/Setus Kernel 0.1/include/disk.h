#ifndef DISK_H
#define DISK_H

void read_disk(unsigned int sector, unsigned char *buffer);

#endif
