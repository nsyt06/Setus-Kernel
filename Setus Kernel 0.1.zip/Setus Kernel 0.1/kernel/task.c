#include "task.h"
#include "video.h"

#define STACK_SIZE 1024  // Size of each task's stack

unsigned int task1_stack[STACK_SIZE];
unsigned int task2_stack[STACK_SIZE];

task_t tasks[2];
task_t *current_task;

void task1() {
    while (1) {
        print_string("Task 1 is running in Setus Kernel\n");
    }
}

void task2() {
    while (1) {
        print_string("Task 2 is running in Setus Kernel\n");
    }
}

void init_tasking() {
    tasks[0].stack_pointer = &task1_stack[STACK_SIZE - 1];
    tasks[1].stack_pointer = &task2_stack[STACK_SIZE - 1];
    tasks[0].id = 1;
    tasks[1].id = 2;
    current_task = &tasks[0];
}

void scheduler() {
    if (current_task == &tasks[0]) {
        current_task = &tasks[1];
    } else {
        current_task = &tasks[0];
    }
}
