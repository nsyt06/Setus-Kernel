#include "disk.h"
#include "io.h"

void read_disk(unsigned int sector, unsigned char *buffer) {
    outb(0x1F7, 0x20);  // Read command
    outb(0x1F2, 1);      // One sector
    outb(0x1F3, sector);
    outb(0x1F4, sector >> 8);
    outb(0x1F5, sector >> 16);
    outb(0x1F6, (sector >> 24) | 0xE0);  // LBA mode

    while ((inb(0x1F7) & 0x80) == 0) {}

    for (int i = 0; i < 512; i++) {
        buffer[i] = inb(0x1F0);  // Read data from the disk
    }
}
