#include "shell.h"
#include "keyboard.h"
#include "video.h"
#include "string.h"

#define MAX_COMMAND_LENGTH 256

void start_shell() {
    char command[MAX_COMMAND_LENGTH];
    int command_pos = 0;

    print_string("Setus Kernel Shell\n");
    print_string("> ");

    while (1) {
        char key = read_key();

        if (key == '\n') {
            command[command_pos] = '\0';
            execute_command(command);
            command_pos = 0;
            print_string("> ");
        } else if (key == '\b') {
            if (command_pos > 0) {
                command_pos--;
                print_char('\b');
            }
        } else {
            command[command_pos++] = key;
            print_char(key);
        }
    }
}

void execute_command(char *command) {
    if (strcmp(command, "hello") == 0) {
        print_string("Hello, Setus Kernel!\n");
    } else {
        print_string("Unknown command\n");
    }
}
