#include "keyboard.h"
#include "io.h"

// Read a single character from the keyboard
char read_key() {
    while (inb(0x64) & 0x01) {
        return inb(0x60);
    }
    return 0;
}
