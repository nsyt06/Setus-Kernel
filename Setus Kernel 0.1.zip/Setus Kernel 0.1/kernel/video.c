#include "video.h"
#include "io.h"

#define VIDEO_MEMORY 0xB8000
#define MAX_WIDTH 80
#define MAX_HEIGHT 25

void clear_screen() {
    unsigned short *video_memory = (unsigned short *)VIDEO_MEMORY;
    for (int i = 0; i < MAX_WIDTH * MAX_HEIGHT; i++) {
        video_memory[i] = (0x0F << 8) | ' ';  // Set the screen to black with white text
    }
}

void print_string(const char *str) {
    unsigned short *video_memory = (unsigned short *)VIDEO_MEMORY;
    int i = 0;
    while (str[i]) {
        video_memory[i] = (0x0F << 8) | str[i];
        i++;
    }
}

void print_char(char c) {
    unsigned short *video_memory = (unsigned short *)VIDEO_MEMORY;
    *video_memory = (0x0F << 8) | c;
}
