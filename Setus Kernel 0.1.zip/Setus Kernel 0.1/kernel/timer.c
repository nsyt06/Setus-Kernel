#include "timer.h"
#include "io.h"

void init_timer(unsigned int frequency) {
    unsigned int divisor = 1193180 / frequency;

    outb(0x43, 0x36);  // PIT configuration
    outb(0x40, divisor & 0xFF);
    outb(0x40, divisor >> 8);
}

void timer_interrupt_handler() {
    scheduler();  // Switch tasks on each timer interrupt
}
