#include "video.h"
#include "keyboard.h"
#include "string.h"
#include "task.h"
#include "timer.h"
#include "shell.h"
#include "disk.h"

// Entry point of the kernel
void kernel_main(void) {
    clear_screen();  // Clear the screen

    // Initialize components
    init_tasking();
    init_timer(100);  // Set timer frequency to 100Hz
    print_string("Setus Kernel Initialized\n");

    // Launch shell (simple command prompt)
    start_shell();
}
